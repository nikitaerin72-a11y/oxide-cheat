// 
// Created by Kriware Project - Oxide Edition
// 

#include "../Include/KittyMemory/MemoryPatch.h"
#include "../Include/ImGui.h"
#include "../Include/RemapTools.h"
#include "../Include/Drawing.h"
#include "../Include/Unity.h"
#include <pthread.h>
#include <unistd.h>

// --- ПЕРЕМЕННЫЕ ХАКОВ ---
bool no_recoil = false;
bool speed_hack = false;
bool fast_bow = false;

// --- ИНТЕРФЕЙС МЕНЮ ---
void DrawMenu() {
    // Если хочешь, можешь оставить Demo для тестов, но лучше выключить
    // ImGui::ShowDemoWindow(); 

    ImGui::SetNextWindowSize(ImVec2(400, 300), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("KRIWARE | Oxide Survival", NULL, ImGuiWindowFlags_NoCollapse)) {
        
        ImGui::TextColored(ImVec4(1, 1, 0, 1), "Developer: Kriware");
        ImGui::Separator();

        // Секция функций
        if (ImGui::CollapsingHeader("Combat")) {
            ImGui::Checkbox("No Recoil", &no_recoil);
            ImGui::Checkbox("Fast Bow", &fast_bow);
        }

        if (ImGui::CollapsingHeader("Movement")) {
            ImGui::Checkbox("SpeedHack x5", &speed_hack);
        }

        ImGui::Separator();
        ImGui::Text("Status: Active");

        ImGui::End();
    }
}

// --- ПОТОК ХАКОВ (Хуки и патчи) ---
void *thread(void *) {
    LOGI("Kriware: Main Thread Loaded");
    
    // Инициализация меню
    initModMenu((void *)DrawMenu);

    // Ждем загрузки библиотеки игры
    do {
        sleep(1);
    } while (!isLibraryLoaded("libil2cpp.so"));

    /* * ПРИМЕР ХУКА (когда найдешь оффсет):
     * DobbyHook(getAbsoluteAddress("libil2cpp.so", 0x123456), (void *)h_Function, (void **)&old_Function);
     */

    LOGI("Kriware: Thread Done");
    pthread_exit(0);
}

// --- СИСТЕМНАЯ ЧАСТЬ (JNI) ---
extern "C" {
    JavaVM *jvm = nullptr;
    JNIEnv *env = nullptr;

    __attribute__((visibility ("default")))
    jint loadJNI(JavaVM *vm) {
        jvm = vm;
        vm->AttachCurrentThread(&env, nullptr);
        return JNI_VERSION_1_6;
    }
}

__attribute__((constructor))
void init() {
    pthread_t t;
    pthread_create(&t, nullptr, thread, nullptr);

    // Маскировка лоадера
    RemapTools::RemapLibrary("libLoader.so");
}
